package package1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UpdatePasswordServlet")
public class UpdatePasswordServlet extends HttpServlet {

	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        int id = Integer.parseInt(request.getParameter("userID"));
        String password = request.getParameter("password");
        String url = "jdbc:sqlite:C:\\Users\\vll\\db\\mydatabase.db"; // Change to your SQLite database URL
        try  {
        	Class.forName("org.sqlite.JDBC");
        	Connection con = DriverManager.getConnection(url);
            String query = "SELECT * FROM underwriter WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String updateQuery = "UPDATE underwriter SET password = ? WHERE id = ?";
                PreparedStatement updatePs = con.prepareStatement(updateQuery);
                updatePs.setString(1, password);
                updatePs.setInt(2, id);
                updatePs.executeUpdate();
                out.println("Password updated successfully for ID: " + id);
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.println("Error: ID " + id + " is not found in underwriter table ");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("Error: Unable to update password. Please try again later.");
        }
    }
}
