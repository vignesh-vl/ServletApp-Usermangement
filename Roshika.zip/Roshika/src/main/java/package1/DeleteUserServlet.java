package package1;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        
        int id = Integer.parseInt(request.getParameter("userID"));

        String url = "jdbc:sqlite:C:\\Users\\vll\\db\\mydatabase.db"; // Change to your SQLite database URL

        try  {
        	Class.forName("org.sqlite.JDBC");
        	Connection con = DriverManager.getConnection(url);
            String query = "SELECT * FROM underwriter WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // ID exists, delete the user
                String deleteQuery = "DELETE FROM underwriter WHERE id = ?";
                PreparedStatement deletePs = con.prepareStatement(deleteQuery);
                deletePs.setInt(1, id);
                deletePs.executeUpdate();

                out.println("User with ID " + id + " deleted successfully");
            } else {
                // ID does not exist, return error message
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                out.println("Error: User with ID " + id + " not found in underwriter table");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("Error: Unable to delete user. Please try again later.");
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
